import java.util.Scanner;

public class DogYears {
	public static void main(String[] args) {
		// TODO: add your code here
	}
}
