public class Coins {
	// TODO: add class components with corresponding comment labels
	
}
