import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class CirclesPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private static final Color c = Color.RED;
    // this font will be used to display the count
    private static final Font font = new Font("Dialog", Font.BOLD, 48);

	private static final int WIDTH = 300;
	private static final int HEIGHT = 300;
	
	// TODO: add model field and outline disk fields
	
	// constructor
	public CirclesPanel() {
	
		// TODO: initialize the fields

	
		setPreferredSize(new Dimension(WIDTH, HEIGHT));
		setBackground(Color.WHITE);

		// Register mouse motion event handler
		addMouseMotionListener(new MouseAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				handleMouseMove(e);
			}
		});

		// Register mouse button click event handler
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				handleMouseClick(e);
			}
		});
	}
	
	// Controller methods
	private void handleMouseMove(MouseEvent e) {
		// TODO: update outline position

	}

	private void handleMouseClick(MouseEvent e) {
		// TODO: place new circle for left click
		//       increase radius for right click

	}
	
	// View method
	@Override
	public void paint(Graphics g) {
		super.paint(g); // paint background
		
		// TODO: draw model Circle first - why?

		
		// TODO: draw the outline
		
		// TODO: draw the count
		
	}
}
