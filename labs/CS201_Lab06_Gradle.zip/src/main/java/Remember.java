import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Remember {
	public static final String PATH = "CS201_Lab06_Gradle/"

	public static void main(String[] args) throws IOException {
		String fileName = "name.txt";
		// TODO: add your code here
	}
}
